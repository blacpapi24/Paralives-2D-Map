# Paralives 2D Map Mod

A top-down 2D town map for Paralives. Press **F7** or click the on-screen button to open a flat overview of every lot in your town. Quickly navigate between lots or switch households without scrolling through the 3D world.

The map renders the town from above once when opened, keeping performance high.

## Features

- **Top-down town overview** with a real orthographic snapshot of your town.
- **Game icons** — lot markers use the game's own category icons (residential, commercial, park, etc.) as circular badges.
- **Your lots are green** with a pulsing glow so they're easy to spot.
- **Bus stops** shown with the game's bus icon — click one to send your active Para there to catch the bus.
- **Filter** lots by category from the "Filters" dropdown (left-click to toggle a type, right-click to solo it).
- **Hover** over any lot to see its name and type.
- **Left-click** a lot to jump the camera to it.
- **Double-click** a lot to switch to that household.
- **Scroll** to zoom, **right-drag** to pan.
- **Custom backdrops** — optionally use a custom map image instead of the 3D snapshot.

---

## Installation

This mod requires **BepInEx 5** (Unity Mono, x64).

1. **Install BepInEx 5** — download BepInEx 5 (Mono x64) and extract it into your Paralives installation folder so that `winhttp.dll` is next to `Paralives.exe`.
2. **Run the game once** to let BepInEx create its folders, then close it.
3. **Install the mod** — place the `Paralives2DMap` folder (containing `Paralives2DMap.dll` and this `README.md`) inside `BepInEx\plugins`. The path should be: `Paralives\BepInEx\plugins\Paralives2DMap\Paralives2DMap.dll`.
4. **Play** — launch Paralives, load a save, and press **F7** to open the map.

---

## Controls

- **F7** — open / close the map (configurable).
- **On-screen button** — click "Open 2D Map" in the top-left corner (can be hidden).
- **Scroll wheel** — zoom in and out.
- **Right-click & drag** — pan the map.
- **Left-click** a lot — move the camera there.
- **Double-click** a lot — switch to that household.
- **Refresh** button — re-render the snapshot after building or time changes.
- **Bus stops** — left-click a stop, then confirm to send your selected Para to it.
- **Filters dropdown** — left-click a category to show/hide it; right-click to show only that one.

---

## Configuration

A config file is created at `BepInEx\config\com.blacpapi24.paralives2dmap.cfg` after the first launch. You can edit it with any text editor.

- `ToggleKey` — key to open/close the map (default: F7).
- `ShowToggleButton` — show or hide the on-screen button.
- `ShowBusStops